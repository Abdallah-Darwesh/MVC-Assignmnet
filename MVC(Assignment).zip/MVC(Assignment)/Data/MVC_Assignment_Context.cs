﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MVC_Assignment_.Models;

namespace MVC_Assignment_.Data
{
    public class MVC_Assignment_Context : DbContext
    {
        public MVC_Assignment_Context (DbContextOptions<MVC_Assignment_Context> options)
            : base(options)
        {
        }

        public DbSet<MVC_Assignment_.Models.Category> Category { get; set; } = default!;
        public DbSet<MVC_Assignment_.Models.Customer> Customer { get; set; } = default!;
        public DbSet<MVC_Assignment_.Models.Order> Order { get; set; } = default!;
        public DbSet<MVC_Assignment_.Models.Product> Product { get; set; } = default!;
        public DbSet<MVC_Assignment_.Models.OrderItem> OrderItem { get; set; } = default!;
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
          
            modelBuilder.Entity<Order>()
                .Property(o => o.InstallAmount)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<OrderItem>()
                .Property(oi => oi.Price)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Product>()
                .Property(p => p.Price)
                .HasColumnType("decimal(18,2)");

            base.OnModelCreating(modelBuilder);
        }

    }
}
